# SonicVitals

ESP32-S3 node (OV2640 camera + INMP441 chest microphone + SSD1306 OLED) streaming to a
Python host that estimates heart rate (camera rPPG + acoustic PCG, fused), respiration
rate and RMSSD, with a browser workstation. Research prototype — not a medical device.

## 1. Flash the node
Pick the build that matches the board:

| Board | Build | Data link | Mic |
|---|---|---|---|
| Single USB-C (CH340 bridge), e.g. this prototype | `esp32s3_wifi` (default) | Wi-Fi, TCP port 3333 | yes |
| Has a native USB connector | `esp32s3` | native USB-CDC | yes |
| Single USB-C, no Wi-Fi wanted | `esp32s3_uart` | UART 1 Mbaud | no (pin conflict) |

```
cd Firmware
pio run -t upload                      # esp32s3_wifi over /dev/cu.usbserial-110
```
Stop the host server (or run it with `SONICVITALS_LINK=wifi`) while flashing: a server probing the
serial port can reset the chip in the middle of an upload ("The chip stopped responding").
Wi-Fi: copy `wifi_secrets.example.h` to `wifi_secrets.h` and fill in your 2.4 GHz network to join it
(the host finds the node as `sonicvitals.local`). Without that file the node starts its own WPA2 hotspot
(name and password in `wifi_secrets.example.h`); join it from the laptop and the host finds the node at
192.168.4.1. The OLED bottom line shows `IP ...` or `AP ...` until the host connects.

## 2. Run host + UI
```
./start.sh                                  # http://localhost:3000
SONICVITALS_WEBCAM=0 ./start.sh             # evaluation sessions: never fall back to the laptop webcam
./start.sh                                  # esp32s3_uart build uses 1 Mbaud (the default)
```
Check the **Device Management** tab: measured frame rate must be >= 5 fps (ideally 10-15),
frames rejected < 1 %, audio blocks lost < 1 %, video source = ESP32-S3.

## 3. Record a session
Experiments tab -> participant ID, condition (C1-C5), notes -> Start. Raw data goes to
`data/sessions/<timestamp>_<participant>/` (frames.csv, audio.wav, audio_blocks.csv,
estimates.csv, meta.json). Add the reference data to the same folder:
- `reference.csv`: `host_time` (Unix s, same computer clock) + `hr_ref`, `rr_ref`, `spo2_ref`
- `rpeaks.csv` (optional): `host_time` of each ECG R peak, for reference RMSSD

## 4. Evaluate (fills paper Tables VI-VIII)
```
python3 analysis/evaluate.py data/sessions/* --out analysis/results --dev-participants P01,P02 --write-calibration
```
Development participants are used only for thresholds and the SpO2 calibration and are
excluded from all reported metrics. Output: `tables.tex`, CSVs, `bland_altman.pdf`.

## Testing without hardware
```
python3 -m pytest backend/tests -q
python3 tools/node_simulator.py --hr 72           # prints a virtual port, e.g. /dev/ttys012
SONICVITALS_PORT=/dev/ttys012 SONICVITALS_BAUD=115200 SONICVITALS_WEBCAM=0 python3 backend/usb_streamer.py
```
Simulated physiology is synthetic: never use it as experimental data.

`Server/` is the older PySide prototype and is not used by `start.sh`. Original pre-fix sources are in `archive/pre_fix/`.

## Demonstration without hardware (simulated, clearly labelled)

```bash
./tools/demo_simulated.sh            # optional: --hr 72 --rr 15
```

Starts `tools/node_simulator.py` (synthetic face video, raw-pixel skin sums and heart sounds)
and the server. The dashboard shows a red **SIMULATED DATA · DEMO MODE** banner and the
source reads **SIMULATOR (SYNTHETIC)** for as long as it runs. Use it to show the pipeline
when the node is unavailable; never present its values as measurements.
