"""Signal-processing core for SonicVitals.

All functions here are pure (no global state) so that the live server
(`usb_streamer.py`) and the offline evaluation (`analysis/evaluate.py`) run
exactly the same code. Section numbers refer to the accompanying paper.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import butter, sosfiltfilt, filtfilt, welch, resample_poly, find_peaks, hilbert

# ---------------------------------------------------------------- constants
FS_OPT = 15.0                 # uniform analysis rate for the optical channel (Hz)
CARDIAC_BAND = (0.75, 2.5)    # 45-150 beats/min
RESP_BAND = (0.15, 0.40)      # 9-24 breaths/min
MAX_GAP_S = 2.0               # dropouts up to this long are bridged by interpolation; longer ones restart the segment
MIN_COVERAGE = 0.8            # share of the segment that must be backed by real (not bridged) frames
MIN_SEG_HR_S = 10.0           # shortest contiguous segment for an HR estimate
MIN_SNR_HR_DB = 0.0           # HR is accepted only above this SNR; noise-only input exceeds it in <5 % of
                              # 10 s segments (95th percentile -0.3 dB, see tests); re-tune on development data
TRACK_HALF_BPM = 12.0         # tracking window around the previous accepted HR
TRACK_POWER_RATIO = 0.5       # keep the in-window peak if it has at least this share of the global peak power
MIN_SEG_RR_S = 15.0           # shortest contiguous segment for an RR estimate
MIN_Q_RR = 0.5                # RR is reported only if this share of 0.05-1 Hz power lies at the peak
                              # (synthetic: breathing ~0.9, noise <= 0.36; re-tune on development data)
NFFT = 4096

FS_AUDIO = 16000
FS_PCG = 1000                 # PCG analysis rate after decimation
PCG_BAND = (25.0, 400.0)
HR_LAG_S = (0.4, 60.0 / 45.0) # 45-150 beats/min
FUSION_DELTA_BPM = 8.0
MIN_RHO_ACOUSTIC = 0.3         # below this the PCG rhythm is too weak to report (re-tune on development data)


# ================================================================ helpers
def last_contiguous_segment(t: np.ndarray, max_gap: float = MAX_GAP_S) -> int:
    """Index at which the most recent gap-free run of timestamps starts."""
    if len(t) < 2:
        return 0
    gaps = np.where(np.diff(t) > max_gap)[0]
    return int(gaps[-1] + 1) if len(gaps) else 0


def resample_uniform(t: np.ndarray, x: np.ndarray, fs: float = FS_OPT):
    """Linearly interpolate irregularly sampled `x` (N or N x C) onto a uniform grid.

    Only the most recent contiguous segment (no gap > MAX_GAP_S) is used.
    Returns (t_uniform, x_uniform); both empty if fewer than 2 samples remain.
    """
    t = np.asarray(t, dtype=float)
    x = np.asarray(x, dtype=float)
    start = last_contiguous_segment(t)
    t, x = t[start:], x[start:]
    if len(t) < 2 or t[-1] - t[0] < 1.0 / fs:
        return np.array([]), np.empty((0,) + x.shape[1:])
    tu = np.arange(t[0], t[-1] + 1e-9, 1.0 / fs)
    if x.ndim == 1:
        return tu, np.interp(tu, t, x)
    return tu, np.column_stack([np.interp(tu, t, x[:, c]) for c in range(x.shape[1])])


def segment_coverage(t: np.ndarray, frame_gap: float = 0.25) -> float:
    """Share of the most recent segment covered by real frames.

    Gaps longer than `frame_gap` (two frame intervals at 8 frames/s) count as
    missing time beyond `frame_gap`; that time is filled by interpolation.
    """
    t = np.asarray(t, dtype=float)
    t = t[last_contiguous_segment(t):]
    if len(t) < 2 or t[-1] <= t[0]:
        return 0.0
    missing = np.sum(np.maximum(0.0, np.diff(t) - frame_gap))
    return float(1.0 - missing / (t[-1] - t[0]))


def standardize(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    sd = np.std(x)
    return (x - np.mean(x)) / sd if sd > 0 else x - np.mean(x)


def bandpass(x: np.ndarray, fs: float, band, order: int) -> np.ndarray:
    """Zero-phase Butterworth band-pass (forward-backward)."""
    b, a = butter(order, [band[0] / (fs / 2), band[1] / (fs / 2)], btype="band")
    padlen = min(len(x) - 1, 3 * max(len(a), len(b)))
    return filtfilt(b, a, x, padlen=padlen)


def parabolic_peak(y: np.ndarray, k: int) -> float:
    """Sub-bin location of a peak at index k (paper Eq. 6)."""
    if k <= 0 or k >= len(y) - 1:
        return float(k)
    a, b, c = y[k - 1], y[k], y[k + 1]
    denom = a - 2 * b + c
    if denom >= 0:                     # not a strict local maximum (flat or concave-up)
        return float(k)
    # The vertex of a parabola through a local maximum lies within half a bin.
    return float(k + np.clip(0.5 * (a - c) / denom, -0.5, 0.5))


def band_peak(freqs: np.ndarray, psd: np.ndarray, band):
    """Interpolated location and bin power of the largest PSD value inside `band`."""
    mask = (freqs >= band[0]) & (freqs <= band[1])
    if not np.any(mask):
        return None, 0.0
    idx = np.where(mask)[0]
    k = int(idx[np.argmax(psd[idx])])
    return float(parabolic_peak(psd, k) * (freqs[1] - freqs[0])), float(psd[k])


def welch_peak(x: np.ndarray, fs: float, band, nperseg: int, nfft: int = NFFT):
    """Welch PSD (Hann, 50 % overlap, zero-padded) and interpolated in-band peak."""
    nperseg = int(min(len(x), nperseg))
    freqs, psd = welch(x, fs=fs, window="hann", nperseg=nperseg,
                       noverlap=nperseg // 2, nfft=max(nfft, nperseg))
    f0, _ = band_peak(freqs, psd, band)
    return f0, freqs, psd


def tracked_peak(freqs: np.ndarray, psd: np.ndarray, band, prior_hz: float | None):
    """Global in-band peak, or the peak near `prior_hz` if it is nearly as strong (paper Sec. V-E).

    Returns (f0, tracked) where tracked is True when the local peak replaced the global one.
    """
    f_g, p_g = band_peak(freqs, psd, band)
    if f_g is None or prior_hz is None:
        return f_g, False
    half = TRACK_HALF_BPM / 60.0
    local = (max(band[0], prior_hz - half), min(band[1], prior_hz + half))
    if local[0] >= local[1]:
        return f_g, False
    f_l, p_l = band_peak(freqs, psd, local)
    if f_l is not None and p_l >= TRACK_POWER_RATIO * p_g and abs(f_l - f_g) > 1e-9:
        return f_l, True
    return f_g, False


def dehaan_snr(freqs: np.ndarray, psd: np.ndarray, f0: float,
               band=(0.5, 4.0), half_fund: float = 0.1, half_harm: float = 0.2) -> float:
    """SNR of de Haan & Jeanne (2013), paper Eq. 7, in dB."""
    inband = (freqs >= band[0]) & (freqs <= band[1])
    signal = inband & ((np.abs(freqs - f0) <= half_fund) | (np.abs(freqs - 2 * f0) <= half_harm))
    noise = inband & ~signal
    ps, pn = np.sum(psd[signal]), np.sum(psd[noise])
    if ps <= 0 or pn <= 0:
        return float("nan")
    return float(10 * np.log10(ps / pn))


def spectral_concentration(freqs, psd, f0, band=CARDIAC_BAND, half: float = 0.1) -> float:
    """Fraction of in-band power within +/- half Hz of f0 (paper Eq. 8)."""
    inband = (freqs >= band[0]) & (freqs <= band[1])
    total = np.sum(psd[inband])
    if total <= 0:
        return 0.0
    near = inband & (np.abs(freqs - f0) <= half)
    return float(np.sum(psd[near]) / total)


# ================================================================ optical
def chrom_pulse(rgb: np.ndarray, L: int | None = None) -> np.ndarray:
    """CHROM projection with overlap-add (paper Eqs. 3-5). `rgb` is N x 3 (R, G, B)."""
    N = len(rgb)
    if L is None:
        L = min(45, max(12, N // 2))
    L = min(L, N)
    h = np.zeros(N)
    for i in range(0, N - L + 1):
        seg = rgb[i:i + L]
        cn = seg / (np.mean(seg, axis=0) + 1e-9) - 1.0
        X = 3.0 * cn[:, 0] - 2.0 * cn[:, 1]
        Y = 1.5 * cn[:, 0] + cn[:, 1] - 1.5 * cn[:, 2]
        sy = np.std(Y)
        alpha = np.std(X) / sy if sy > 0 else 0.0
        s = X - alpha * Y
        h[i:i + L] += s - np.mean(s)
    return h


def trend_decomposition(x: np.ndarray):
    """Moving-average split into trend / pulsatile / first difference (paper Sec. V-F)."""
    N = len(x)
    W = min(14, max(4, N // 4))
    trend = np.convolve(x, np.ones(W) / W, mode="same")
    pulsatile = x - trend
    diff = np.diff(x, prepend=x[0])
    ratio = float(np.sum(pulsatile ** 2) / (np.sum(trend ** 2) + 1e-12))
    return trend, pulsatile, diff, ratio


def estimate_optical(t, rgb, method: str = "chrom", fs: float = FS_OPT,
                     spo2_calibration: dict | None = None, prior_hr: float | None = None) -> dict:
    """Optical HR / RR / SpO2-ratio estimate from timestamped ROI means.

    t   : frame timestamps in seconds (only frames that passed the face gate)
    rgb : N x 3 array of ROI mean (R, G, B)
    method: "chrom" or "green" (green channel only, used for the ablation)
    prior_hr: previous accepted HR (beats/min) for peak tracking, or None
    Returns a dict; quantities that cannot be estimated are None. `hr_ok` is True
    when the HR estimate passes the SNR and coverage gates.
    """
    out = dict(hr=None, hr_ok=False, tracked=False, f0=None, snr=None, quality=0.0, rr=None, rr_quality=0.0,
               spo2_ratio=None, spo2=None, coverage=0.0,
               segment_s=0.0, fs=fs, bvp=np.array([]), resp=np.array([]),
               freqs=np.array([]), psd=np.array([]),
               trend=np.array([]), pulsatile=np.array([]), diff=np.array([]), motion_ratio=None)
    tu, xu = resample_uniform(t, rgb, fs)
    if len(tu) < 8:
        return out
    seg_s = tu[-1] - tu[0]
    out["segment_s"] = float(seg_s)
    out["coverage"] = segment_coverage(t)
    if len(tu) < 25:
        return out

    pulse = chrom_pulse(xu) if method == "chrom" else xu[:, 1] - np.mean(xu[:, 1])
    if method == "green":
        pulse = -pulse    # blood absorbs green: invert so systole is positive
    bvp = standardize(bandpass(pulse, fs, CARDIAC_BAND, 3))
    out["bvp"] = bvp
    out["trend"], out["pulsatile"], out["diff"], out["motion_ratio"] = trend_decomposition(bvp)

    if seg_s >= MIN_SEG_HR_S:
        # SNR is evaluated on the un-band-passed pulse so the harmonic is not filtered out.
        _, freqs, psd = welch_peak(standardize(pulse), fs, CARDIAC_BAND, nperseg=256)
        prior_hz = None if prior_hr is None else prior_hr / 60.0
        f0, tracked = tracked_peak(freqs, psd, CARDIAC_BAND, prior_hz)
        if f0 is not None:
            snr = dehaan_snr(freqs, psd, f0)
            out.update(hr=60.0 * f0, f0=f0, freqs=freqs, psd=psd, snr=snr, tracked=tracked,
                       quality=spectral_concentration(freqs, psd, f0),
                       hr_ok=bool(np.isfinite(snr) and snr >= MIN_SNR_HR_DB
                                  and out["coverage"] >= MIN_COVERAGE))

        # SpO2 ratio-of-ratios from band-passed AC (paper Eq. 13); uncalibrated unless A, B given.
        r_ac = np.std(bandpass(xu[:, 0], fs, CARDIAC_BAND, 3))
        b_ac = np.std(bandpass(xu[:, 2], fs, CARDIAC_BAND, 3))
        r_dc, b_dc = np.mean(xu[:, 0]), np.mean(xu[:, 2])
        if b_ac > 0 and r_dc > 0 and b_dc > 0:
            ratio = (r_ac / r_dc) / (b_ac / b_dc)
            out["spo2_ratio"] = float(ratio)
            if spo2_calibration and "A" in spo2_calibration and "B" in spo2_calibration:
                out["spo2"] = float(spo2_calibration["A"] - spo2_calibration["B"] * ratio)

    green = xu[:, 1]
    out["resp"] = standardize(bandpass(green - np.mean(green), fs, RESP_BAND, 2))
    out["rr_quality"] = 0.0
    if seg_s >= MIN_SEG_RR_S:
        # Peak search on the un-band-passed green trace so the in-band power share is meaningful.
        g = standardize(green - np.mean(green))
        fr, rfreqs, rpsd = welch_peak(g, fs, RESP_BAND, nperseg=len(g))
        if fr is not None:
            # Half-width of one nominal resolution bin (1/T) around the peak.
            q = spectral_concentration(rfreqs, rpsd, fr, band=(0.05, 1.0), half=1.0 / seg_s)
            out["rr_quality"] = q
            out["rr"] = 60.0 * fr if q >= MIN_Q_RR else None
    return out


# ================================================================ acoustic
def pcg_envelope(x16k: np.ndarray, fs: int = FS_AUDIO):
    """Band-pass 25-400 Hz, decimate to 1 kHz, Shannon energy smoothed over 20 ms.

    Returns (band-passed 1 kHz signal, envelope at 1 kHz, envelope at 100 Hz).
    """
    x = np.asarray(x16k, dtype=float)
    x = x - np.mean(x)
    sos = butter(4, [PCG_BAND[0] / (fs / 2), PCG_BAND[1] / (fs / 2)], btype="band", output="sos")
    xb = sosfiltfilt(sos, x)
    x1k = resample_poly(xb, 1, fs // FS_PCG)
    peak = np.max(np.abs(x1k))
    if peak <= 0:
        return x1k, np.zeros_like(x1k), np.zeros(len(x1k) // 10)
    xn = x1k / peak
    se = -(xn ** 2) * np.log(xn ** 2 + 1e-12)                  # Shannon energy (Eq. 10)
    win = int(0.020 * FS_PCG)
    env1k = np.convolve(se, np.ones(win) / win, mode="same")   # 20 ms smoothing, hop 1 ms
    env100 = env1k[::10]                                       # 10 ms hop
    return x1k, standardize(env1k), standardize(env100)


def estimate_acoustic(x16k: np.ndarray, t0: float = 0.0, fs: int = FS_AUDIO) -> dict:
    """PCG heart rate by envelope autocorrelation (paper Eq. 11) and S1 beat times.

    t0 is the timestamp (s) of the first sample, so beat times are absolute.
    """
    out = dict(hr=None, rho=0.0, beats=np.array([]), rms=0.0, x1k=np.array([]), env=np.array([]))
    if len(x16k) < fs * 3:
        return out
    out["rms"] = float(np.sqrt(np.mean((np.asarray(x16k, float) - np.mean(x16k)) ** 2)))
    x1k, env1k, env100 = pcg_envelope(x16k, fs)
    out["x1k"], out["env"] = x1k, env1k

    e = env100 - np.mean(env100)
    acf = np.correlate(e, e, mode="full")[len(e) - 1:]
    if acf[0] <= 0:
        return out
    acf = acf / acf[0]
    lo, hi = int(HR_LAG_S[0] * 100), int(HR_LAG_S[1] * 100)
    if hi >= len(acf):
        return out
    k = lo + int(np.argmax(acf[lo:hi + 1]))
    tau = parabolic_peak(acf, k) / 100.0
    out["hr"] = 60.0 / tau
    out["rho"] = float(np.clip(acf[k], 0.0, 1.0))

    # Beat fiducials: the Shannon energy de-emphasizes the loudest sound, so S1 is
    # located on the Hilbert amplitude envelope instead (20 ms smoothing, 1 ms
    # resolution), taking the largest peak within each 0.6*tau neighbourhood.
    amp = np.abs(hilbert(x1k))
    win = int(0.020 * FS_PCG)
    amp = np.convolve(amp, np.ones(win) / win, mode="same")
    dist = max(1, int(0.6 * tau * FS_PCG))
    peaks, _ = find_peaks(amp, distance=dist, height=np.median(amp))
    out["beats"] = t0 + peaks / FS_PCG
    return out


def clean_ibis(beat_times: np.ndarray):
    """Inter-beat intervals with physiological and median-deviation rejection."""
    if len(beat_times) < 3:
        return np.array([])
    ibi = np.diff(np.sort(beat_times))
    ibi = ibi[(ibi >= 0.4) & (ibi <= 1.5)]
    if len(ibi) < 2:
        return np.array([])
    med = np.median(ibi)
    return ibi[np.abs(ibi - med) <= 0.2 * med]


def rmssd_ms(beat_times: np.ndarray, min_intervals: int = 20):
    """RMSSD (ms) over successive clean inter-beat intervals; None if too few."""
    ibi = clean_ibis(beat_times)
    if len(ibi) < min_intervals:
        return None
    return float(1000.0 * np.sqrt(np.mean(np.diff(ibi) ** 2)))


# ================================================================ fusion
def fuse_hr(hr_o, w_o, hr_a, w_a, delta: float = FUSION_DELTA_BPM) -> dict:
    """Quality-weighted fusion with agreement gate (paper Eq. 12).

    Weights must already include the gating terms (g_o, g_a). Returns
    {hr, source, w_o, w_a, disagreement} with hr None if no channel is usable.
    """
    o_ok = hr_o is not None and w_o > 0
    a_ok = hr_a is not None and w_a > 0
    res = dict(hr=None, source=None, w_o=float(w_o if o_ok else 0.0),
               w_a=float(w_a if a_ok else 0.0), disagreement=False)
    if o_ok and a_ok:
        if abs(hr_o - hr_a) <= delta:
            res.update(hr=(w_o * hr_o + w_a * hr_a) / (w_o + w_a), source="fused")
        else:
            res["disagreement"] = True
            if w_o >= w_a:
                res.update(hr=hr_o, source="optical")
            else:
                res.update(hr=hr_a, source="acoustic")
    elif o_ok:
        res.update(hr=hr_o, source="optical")
    elif a_ok:
        res.update(hr=hr_a, source="acoustic")
    return res
